extends RefCounted
## Generates a random continent: a grid of cells split into named countries,
## each with its own people, places and traits. Pure data, no rendering.

const W := 72
const H := 48

## start: added to the country's starting meters.
## mult:  multiplies LOSSES for that meter in that country.
const TRAITS := {
	"minority_region": {"desc": "a restive {minority} minority in {region}", "start": {"people": -5}, "mult": {}},
	"strong_army": {"desc": "an army that is a power in its own right", "start": {"army": -5}, "mult": {"army": 1.5}},
	"resource": {"desc": "an economy that runs on {resource}", "start": {"elites": 5}, "mult": {"elites": 1.25}},
	"hostile_neighbor": {"desc": "an old feud with {neighbor}", "start": {"army": 5}, "mult": {}},
	"young_population": {"desc": "a young, underemployed population", "start": {"people": -5}, "mult": {"people": 1.25}},
	"police_state": {"desc": "a security service that is everywhere", "start": {"police": 5, "people": -5}, "mult": {"police": 1.5}},
	"fragile_democracy": {"desc": "an elected parliament and a free press", "start": {"people": 5}, "mult": {"standing": 1.5}},
	"port": {"desc": "trade that flows through the port of {city}", "start": {"elites": 5}, "mult": {}},
	"religious": {"desc": "a church that commands real loyalty", "start": {}, "mult": {}},
	"indebted": {"desc": "heavy debts to foreign creditors", "start": {"elites": -5}, "mult": {}},
}

const PALETTE := [
	"e07a5f", "81b29a", "f2cc8f", "6d9dc5", "c98bb9", "9bc53d",
	"e5989b", "5fa8a0", "d4a373", "8e9aaf", "b5838d", "a3b18a",
]
const C_START := ["Val", "Kor", "Est", "Mar", "Dra", "Sel", "Tor", "Bel", "Nor", "Vesh", "Ald", "Ruth", "Zem", "Lith", "Osk", "Cas", "Mor", "Hal", "Ser", "Tav", "Gry", "Brun", "Syl", "Rad"]
const C_END := ["ovia", "ania", "mark", "land", "eria", "garia", "onia", "avia", "enia", "ia", "ary", "aria"]
const T_START := ["Kras", "Vel", "Nov", "Brod", "Stra", "Mil", "Hav", "Lin", "Orz", "Tem", "Dub", "Sar", "Pel", "Gor", "Ves", "Rim", "Alt", "Zar", "Kol", "Bry"]
const T_END := ["burg", "grad", "stadt", "ov", "ice", "ford", "haven", "pol", "ava", "berg", "mir", "itz", "ona", "sk"]
const FIRST := ["Anton", "Mira", "Stefan", "Irena", "Lukas", "Dara", "Viktor", "Elsa", "Pavel", "Nadia", "Tomas", "Ilse", "Marek", "Sofia", "Emil", "Vera"]
const LAST := ["Varga", "Okros", "Halden", "Petrov", "Lind", "Marek", "Brandt", "Soren", "Kovac", "Adler", "Rusu", "Weiss", "Dragan", "Holm", "Tesar", "Bauer", "Novak", "Krol"]
const M_ROOT := ["Vahl", "Sorb", "Kesh", "Ruth", "Tavar", "Lem", "Oran", "Dzur", "Halk", "Mirn"]
const REGION := ["the %s Highlands", "the %s Marches", "the %s Valley", "the %s Coast", "Upper %s", "the %s Basin"]
const RESOURCES := ["copper", "coal", "natural gas", "lithium", "oil", "timber", "nickel"]

var rng := RandomNumberGenerator.new()
var height := PackedFloat32Array()  # per cell; above 0 is land
var owner := PackedInt32Array()     # per cell; country id, or -1 for sea
var countries: Array = []


func idx(x: int, y: int) -> int:
	return y * W + x


func is_land(i: int) -> bool:
	return height[i] > 0.0


func generate(seed_value: int, country_count := 10) -> void:
	rng.seed = seed_value
	_make_land()
	_make_countries(country_count)
	_describe_countries()


# ---------- land ----------

func _make_land() -> void:
	height.resize(W * H)
	for attempt in 6:
		var noise := FastNoiseLite.new()
		noise.seed = rng.randi()
		noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
		noise.frequency = 0.045
		noise.fractal_octaves = 4
		var land := 0
		for y in H:
			for x in W:
				var nx := (x + 0.5) / W * 2.0 - 1.0
				var ny := (y + 0.5) / H * 2.0 - 1.0
				var d2 := nx * nx * 0.9 + ny * ny * 1.1
				var h := noise.get_noise_2d(x, y) * 0.55 + 0.42 - d2 * 0.95
				if x == 0 or y == 0 or x == W - 1 or y == H - 1:
					h = minf(h, -0.1)  # always sea at the map edge
				height[idx(x, y)] = h
				if h > 0.0:
					land += 1
		if land > W * H * 0.3:
			return


func _neighbors4(i: int) -> Array[int]:
	var out: Array[int] = []
	var x := i % W
	var y := i / W
	if x > 0: out.append(i - 1)
	if x < W - 1: out.append(i + 1)
	if y > 0: out.append(i - W)
	if y < H - 1: out.append(i + W)
	return out


# ---------- countries ----------

func _make_countries(count: int) -> void:
	for attempt in 12:
		_grow_countries(count)
		var smallest := 999999
		for c in countries:
			smallest = mini(smallest, c["cells"].size())
		if smallest >= 45:
			return


func _grow_countries(count: int) -> void:
	owner.resize(W * H)
	owner.fill(-1)
	var land_cells: Array[int] = []
	for i in W * H:
		if height[i] > 0.05:
			land_cells.append(i)

	# Spread the starting points out: each new one is the best of 40 tries.
	var seeds: Array[int] = [land_cells[rng.randi() % land_cells.size()]]
	while seeds.size() < count:
		var best := -1
		var best_d := -1.0
		for t in 40:
			var c: int = land_cells[rng.randi() % land_cells.size()]
			var d := 1e9
			for s in seeds:
				d = minf(d, Vector2(c % W - s % W, c / W - s / W).length())
			if d > best_d:
				best_d = d
				best = c
		seeds.append(best)

	# Grow every country outward at random until the land is used up.
	# High ground resists being claimed, so borders tend to follow ridges.
	var frontier: Array = []
	for c in seeds.size():
		owner[seeds[c]] = c
		for n in _neighbors4(seeds[c]):
			if is_land(n):
				frontier.append([n, c])
	while not frontier.is_empty():
		var k := rng.randi() % frontier.size()
		var item: Array = frontier[k]
		frontier[k] = frontier[-1]
		frontier.pop_back()
		var cell: int = item[0]
		if owner[cell] != -1:
			continue
		if height[cell] > 0.3 and rng.randf() < 0.6:
			frontier.append(item)
			continue
		owner[cell] = item[1]
		for n in _neighbors4(cell):
			if is_land(n) and owner[n] == -1:
				frontier.append([n, item[1]])

	# Islands nobody reached go to the nearest country across the water.
	var label := owner.duplicate()
	var queue: Array[int] = []
	for i in W * H:
		if label[i] != -1:
			queue.append(i)
	var head := 0
	while head < queue.size():
		var cell := queue[head]
		head += 1
		for n in _neighbors4(cell):
			if label[n] == -1:
				label[n] = label[cell]
				queue.append(n)
	for i in W * H:
		if is_land(i) and owner[i] == -1:
			owner[i] = label[i]

	countries.clear()
	for c in count:
		countries.append({"id": c, "cells": [], "neighbors": [], "coast": []})
	for i in W * H:
		var o := owner[i]
		if o == -1:
			continue
		countries[o]["cells"].append(i)
		for n in _neighbors4(i):
			if not is_land(n):
				if not countries[o]["coast"].has(i):
					countries[o]["coast"].append(i)
			elif owner[n] != o and not countries[o]["neighbors"].has(owner[n]):
				countries[o]["neighbors"].append(owner[n])


func cell_pos(i: int) -> Vector2:
	return Vector2(i % W + 0.5, i / W + 0.5)


func _farthest_from(cells: Array, from: Vector2) -> int:
	var best: int = cells[0]
	var best_d := -1.0
	for t in 12:
		var c: int = cells[rng.randi() % cells.size()]
		var d := cell_pos(c).distance_to(from)
		if d > best_d:
			best_d = d
			best = c
	return best


func _pick(list: Array) -> String:
	return list[rng.randi() % list.size()]


func _unique(used: Dictionary, starts: Array, ends: Array) -> String:
	for t in 50:
		var name := _pick(starts) + _pick(ends)
		if not used.has(name):
			used[name] = true
			return name
	return _pick(starts) + _pick(ends)


func _demonym(name: String) -> String:
	if name.ends_with("ia"):
		return name + "n"
	if name.ends_with("ary"):
		return name.trim_suffix("y") + "ian"
	if name.ends_with("mark") or name.ends_with("land"):
		return name + "er"
	return name + "ian"


func _describe_countries() -> void:
	var used := {}
	var stems := C_START.duplicate()
	for i in range(stems.size() - 1, 0, -1):
		var j := rng.randi() % (i + 1)
		var swap = stems[i]
		stems[i] = stems[j]
		stems[j] = swap
	var colors := PALETTE.duplicate()
	for i in range(colors.size() - 1, 0, -1):  # shuffle with our own rng
		var j := rng.randi() % (i + 1)
		var tmp = colors[i]
		colors[i] = colors[j]
		colors[j] = tmp

	for c in countries:
		var stem: String = stems.pop_back()
		c["name"] = stem + _pick(C_END)
		used[c["name"]] = true
		c["demonym"] = _demonym(c["name"])
		c["color"] = Color(colors[c["id"] % colors.size()])

		var centroid := Vector2.ZERO
		for cell in c["cells"]:
			centroid += cell_pos(cell)
		centroid /= maxf(1.0, c["cells"].size())
		c["centroid"] = centroid
		var cap: int = c["cells"][0]
		for cell in c["cells"]:
			if cell_pos(cell).distance_to(centroid) < cell_pos(cap).distance_to(centroid):
				cap = cell
		c["capital_cell"] = cap
		c["capital"] = _unique(used, T_START, T_END)

		c["leader"] = _pick(FIRST) + " " + _pick(LAST)
		c["general"] = "General " + _pick(LAST)
		c["chief"] = "Director " + _pick(LAST)
		c["minority"] = _pick(M_ROOT)
		c["region"] = _pick(REGION) % c["minority"]
		c["resource"] = _pick(RESOURCES)

		var pool := ["minority_region", "strong_army", "resource", "young_population", "religious", "indebted"]
		pool.append(_pick(["police_state", "fragile_democracy"]))
		if not c["coast"].is_empty():
			pool.append("port")
		if not c["neighbors"].is_empty():
			pool.append("hostile_neighbor")
		var traits: Array = []
		var want := 2 + rng.randi() % 2
		while traits.size() < want and not pool.is_empty():
			var k := rng.randi() % pool.size()
			traits.append(pool[k])
			pool.remove_at(k)
		c["traits"] = traits

		# A port city has to be on the coast.
		var city_from: Array = c["coast"] if traits.has("port") else c["cells"]
		c["city_cell"] = _farthest_from(city_from, cell_pos(cap))
		c["city"] = _unique(used, T_START, T_END)

	# Neighbour names need every country named first.
	for c in countries:
		var nb: Array = c["neighbors"]
		if nb.is_empty():  # island nation: use the closest country instead
			var best := -1
			for o in countries:
				if o["id"] != c["id"] and (best == -1 or o["centroid"].distance_to(c["centroid"]) < countries[best]["centroid"].distance_to(c["centroid"])):
					best = o["id"]
			c["neighbor"] = countries[best]["name"]
		else:
			c["neighbor"] = countries[nb[rng.randi() % nb.size()]]["name"]


## Replaces {country}, {capital}, {general} and so on with this country's details.
func fill(text: String, c: Dictionary) -> String:
	return text.format({
		"country": c["name"], "demonym": c["demonym"], "capital": c["capital"],
		"city": c["city"], "leader": c["leader"], "general": c["general"],
		"chief": c["chief"], "minority": c["minority"], "region": c["region"],
		"resource": c["resource"], "neighbor": c["neighbor"],
	})


func describe_traits(c: Dictionary) -> String:
	var parts: Array[String] = []
	for t in c["traits"]:
		parts.append(fill(TRAITS[t]["desc"], c))
	var text := "; ".join(parts)
	return text.left(1).to_upper() + text.substr(1) + "."
