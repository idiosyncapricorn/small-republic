extends Node3D
## Yes, Excellency - main game.
##
## You lead the Concord, an alliance spreading across a randomly generated
## continent. Member countries bring you their crises; you type what you want
## done; a small local LLM maps your words to a pre-written outcome.
##
## Each month you can answer one crisis. The others keep counting down.

const WorldGen := preload("res://scripts/world_gen.gd")
const MapView := preload("res://scripts/map_view.gd")
const CameraRig := preload("res://scripts/camera_rig.gd")
const Llm := preload("res://scripts/llm.gd")

@export var model := "gemma3:4b"
@export var ollama_url := "http://localhost:11434"
## Skip the model and use keyword matching.
@export var use_mock := false
## Show how long the model took on each decision.
@export var show_timing := true
@export_range(4, 12) var country_count := 10
## 0 gives a new random map every game.
@export var map_seed := 0

const CRISES_PATH := "res://data/crises.json"
const MONTHS := 24        # survive this long to win
const START := 40         # starting value of each country's meters
const PATIENCE := 3       # off-topic answers allowed
const MAX_TRIES := 3      # attempts at one crisis before it resolves itself
const DEADLINE := 3       # months a crisis waits for you
const JOIN_EVERY := 3     # a new country joins every N months
const MAX_LOST := 3       # lose this many members and the Concord is finished
const LOST_STANDING := -8
const FACTIONS := {
	"people": "The People",
	"army": "The Army",
	"elites": "The Elites",
	"police": "Security Service",
}
const FALLS := {
	"people": "REVOLUTION IN {country}. The government you backed has fled {capital}. The new one owes you nothing.",
	"army": "COUP IN {country}. {general} has announced a 'period of national correction' and suspended the country's membership.",
	"elites": "COLLAPSE IN {country}. The money left first and the ministers followed. Whoever governs next will not be taking your calls.",
	"police": "{country} HAS GONE DARK. {chief} answers to nobody now, least of all you.",
}
const DEFLECT := [
	"I will pretend I did not hear that.",
	"Excellency. The crisis.",
	"The council is beginning to ask whether you are well.",
]

var rng := RandomNumberGenerator.new()
var crises: Array = []
var world: RefCounted
var states: Array = []      # one Dictionary per country
var use_count := {}         # crisis id -> times used this game
var home := 0
var month := 1
var standing := 50
var patience := PATIENCE
var lost := 0
var selected := -1
var briefed := -1           # country whose briefing is currently on screen
var busy := false
var game_over := false

var map: Node3D
var rig: Node3D
var llm: Node
var ui := {}
var bars := {}


func _ready() -> void:
	_build_world_nodes()
	_build_ui()
	crises = _load_crises()
	if crises.is_empty():
		_say("[color=red]Could not load %s[/color]" % CRISES_PATH)
		return
	llm.model = model
	llm.url = ollama_url
	llm.use_mock = use_mock
	if not use_mock:
		_say("[i]Loading model...[/i]")
		if not await llm.warm_up():
			llm.use_mock = true
			_say("[color=orange]Could not reach Ollama at %s with model '%s'. Using keyword matching instead.[/color]" % [ollama_url, model])
	_new_game()


# ---------- scene ----------

func _build_world_nodes() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.55, 0.75, 0.9)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(1, 1, 1)
	env.ambient_light_energy = 0.3
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -35, 0)
	sun.light_energy = 0.75
	sun.shadow_enabled = true
	add_child(sun)

	map = MapView.new()
	add_child(map)
	rig = CameraRig.new()
	add_child(rig)
	llm = Llm.new()
	add_child(llm)


func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)

	# Top bar
	var top := PanelContainer.new()
	top.position = Vector2(12, 12)
	layer.add_child(top)
	var top_row := HBoxContainer.new()
	top_row.add_theme_constant_override("separation", 14)
	top.add_child(top_row)
	ui["month"] = Label.new()
	top_row.add_child(ui["month"])
	var standing_label := Label.new()
	standing_label.text = "Standing abroad"
	top_row.add_child(standing_label)
	ui["standing"] = ProgressBar.new()
	ui["standing"].custom_minimum_size = Vector2(140, 0)
	ui["standing"].size_flags_vertical = Control.SIZE_SHRINK_CENTER
	top_row.add_child(ui["standing"])
	ui["status"] = Label.new()
	top_row.add_child(ui["status"])

	var hint := Label.new()
	hint.text = "Click a country marked !   Right-drag: rotate   Middle-drag: pan   Wheel: zoom"
	hint.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT, Control.PRESET_MODE_MINSIZE, 12)
	hint.add_theme_color_override("font_color", Color(0.1, 0.15, 0.25))
	hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(hint)

	# Side panel
	var panel := PanelContainer.new()
	panel.anchor_left = 1.0
	panel.anchor_right = 1.0
	panel.anchor_bottom = 1.0
	panel.offset_left = -440
	layer.add_child(panel)
	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 12)
	panel.add_child(margin)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 8)
	margin.add_child(col)

	ui["title"] = Label.new()
	ui["title"].add_theme_font_size_override("font_size", 24)
	col.add_child(ui["title"])
	ui["traits"] = Label.new()
	ui["traits"].autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	ui["traits"].add_theme_color_override("font_color", Color(0.75, 0.75, 0.78))
	col.add_child(ui["traits"])

	var grid := GridContainer.new()
	grid.columns = 2
	col.add_child(grid)
	for key in FACTIONS:
		var name_label := Label.new()
		name_label.text = FACTIONS[key]
		name_label.custom_minimum_size.x = 130
		grid.add_child(name_label)
		var bar := ProgressBar.new()
		bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.add_child(bar)
		bars[key] = bar
	ui["grid"] = grid
	col.add_child(HSeparator.new())

	ui["log"] = RichTextLabel.new()
	ui["log"].bbcode_enabled = true
	ui["log"].scroll_following = true
	ui["log"].size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(ui["log"])

	ui["input"] = LineEdit.new()
	ui["input"].text_submitted.connect(_on_submit)
	col.add_child(ui["input"])


func _say(bbcode: String) -> void:
	ui["log"].append_text(bbcode + "\n")


func _load_crises() -> Array:
	var file := FileAccess.open(CRISES_PATH, FileAccess.READ)
	if file == null:
		return []
	var data = JSON.parse_string(file.get_as_text())
	return data if typeof(data) == TYPE_ARRAY else []


# ---------- setup ----------

func _new_game() -> void:
	var seed_value := map_seed if map_seed != 0 else int(Time.get_unix_time_from_system() * 1000.0) % 2147483647
	rng.seed = seed_value
	world = WorldGen.new()
	world.generate(seed_value, country_count)
	map.build(world)

	states.clear()
	for c in world.countries:
		states.append({"status": "locked", "meters": {}, "flags": {}, "used": [], "crisis": null})
	use_count.clear()
	month = 1
	standing = 50
	patience = PATIENCE
	lost = 0
	selected = -1
	briefed = -1
	game_over = false
	busy = false

	# Your seat: a country with neighbours, so the Concord has room to grow.
	home = rng.randi() % world.countries.size()
	for t in 20:
		if world.countries[home]["neighbors"].size() >= 2:
			break
		home = rng.randi() % world.countries.size()
	_activate(home)
	var nb: Array = world.countries[home]["neighbors"]
	if not nb.is_empty():
		_activate(nb[rng.randi() % nb.size()])

	_say("\n[b]YES, EXCELLENCY[/b]")
	_say("You lead the Concord, a young alliance on a continent that does not trust it. Your seat is in [b]%s[/b]. Member governments bring you the decisions they cannot afford to be seen making." % _name(home))
	_say("You can answer one crisis a month. The rest keep counting down. Hold the Concord together for %d months." % MONTHS)
	_select(home)
	_advance()


func _name(id: int) -> String:
	return world.countries[id]["name"]


func _active() -> Array[int]:
	var out: Array[int] = []
	for id in states.size():
		if states[id]["status"] == "active":
			out.append(id)
	return out


func _activate(id: int) -> void:
	var c: Dictionary = world.countries[id]
	var meters := {}
	for key in FACTIONS:
		meters[key] = START + rng.randi_range(-4, 4)
	for t in c["traits"]:
		var start: Dictionary = WorldGen.TRAITS[t]["start"]
		for key in start:
			meters[key] += start[key]
	states[id]["meters"] = meters
	states[id]["status"] = "active"
	map.set_state(id, "active", id == selected)


func _join_country() -> void:
	var near: Array[int] = []
	var any: Array[int] = []
	for id in states.size():
		if states[id]["status"] != "locked":
			continue
		any.append(id)
		for n in world.countries[id]["neighbors"]:
			if states[n]["status"] == "active":
				near.append(id)
				break
	var pool := near if not near.is_empty() else any
	if pool.is_empty():
		return
	var id: int = pool[rng.randi() % pool.size()]
	_activate(id)
	_say("\n[color=#7fc8ff][b]%s has joined the Concord.[/b] It brings %s[/color]" % [_name(id), _lower_first(world.describe_traits(world.countries[id]))])


func _lower_first(text: String) -> String:
	return text.left(1).to_lower() + text.substr(1)


# ---------- months and crises ----------

func _pending() -> Array[int]:
	var out: Array[int] = []
	for id in _active():
		if states[id]["crisis"] != null:
			out.append(id)
	return out


## Starts months until one has a crisis to answer (or the game ends).
func _advance() -> void:
	while not game_over:
		_begin_month()
		if not _pending().is_empty():
			break
		_say("[color=gray]Month %d passes quietly.[/color]" % month)
		month += 1
		if month > MONTHS:
			_win()
	_brief_selected()
	_refresh()


func _begin_month() -> void:
	if month > 1 and (month - 1) % JOIN_EVERY == 0:
		_join_country()
	var active := _active()
	var chance := clampf(1.5 / active.size(), 0.15, 0.5)
	for id in active:
		if states[id]["crisis"] != null:
			continue
		var follow = _due_followup(id)
		if follow != null:
			_spawn(id, follow)
		elif rng.randf() < chance:
			_spawn_random(id)
	if _pending().is_empty():
		for t in 8:
			if _spawn_random(active[rng.randi() % active.size()]):
				break


func _due_followup(id: int):
	var st: Dictionary = states[id]
	for def in crises:
		if not def.has("after") or st["used"].has(def["id"]):
			continue
		var flag: String = def["after"]["flag"]
		if st["flags"].has(flag) and month - int(st["flags"][flag]) >= int(def["after"]["delay"]):
			return def
	return null


func _spawn_random(id: int) -> bool:
	var traits: Array = world.countries[id]["traits"]
	var best: Array = []
	var best_count := 999999
	for def in crises:
		if def.has("after") or states[id]["used"].has(def["id"]):
			continue
		var ok := true
		for need in def["requires"]:
			if not traits.has(need):
				ok = false
		if not ok:
			continue
		# Prefer crises the player has seen least this game.
		var n: int = use_count.get(def["id"], 0)
		if n < best_count:
			best_count = n
			best = [def]
		elif n == best_count:
			best.append(def)
	if best.is_empty():
		return false
	_spawn(id, best[rng.randi() % best.size()])
	return true


func _spawn(id: int, def: Dictionary) -> void:
	var c: Dictionary = world.countries[id]
	var filled: Dictionary = def.duplicate(true)
	for key in ["title", "briefing", "nudge"]:
		filled[key] = world.fill(filled[key], c)
	for o in filled["outcomes"]:
		o["label"] = world.fill(o["label"], c)
		o["result"] = world.fill(o["result"], c)
	filled["stalled"]["result"] = world.fill(filled["stalled"]["result"], c)

	states[id]["crisis"] = {"def": filled, "deadline": DEADLINE, "tries": 0}
	states[id]["used"].append(def["id"])
	use_count[def["id"]] = use_count.get(def["id"], 0) + 1
	map.set_alert(id, DEADLINE)
	_say("\n[color=orange]New crisis in [b]%s[/b]: %s[/color]" % [c["name"], filled["title"]])


func _end_month(answered: int) -> void:
	for id in _pending():
		if id == answered:
			continue
		var cr: Dictionary = states[id]["crisis"]
		cr["deadline"] -= 1
		if cr["deadline"] <= 0:
			_say("\n[color=#ff8a80][b]%s: %s[/b]\nYou gave no answer in time.[/color]" % [_name(id), cr["def"]["title"]])
			_resolve(id, cr["def"]["stalled"])
			if game_over:
				return
		else:
			map.set_alert(id, cr["deadline"])
	month += 1
	if month > MONTHS:
		_win()
		return
	_advance()


# ---------- player input ----------

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if world == null or game_over:
			return
		var id: int = map.pick(rig.camera, event.position)
		if id != -1:
			_select(id)


func _select(id: int) -> void:
	if busy:
		return
	var previous := selected
	selected = id
	if previous != -1 and previous != id:
		map.set_state(previous, states[previous]["status"], false)
	map.set_state(id, states[id]["status"], true)

	_brief_selected()
	_refresh()


## Shows the advisor's briefing for the selected country, once per crisis.
func _brief_selected() -> void:
	if selected == -1 or game_over:
		return
	var cr = states[selected]["crisis"]
	if cr != null and briefed != selected:
		briefed = selected
		_say("\n[b]%s: %s[/b]" % [_name(selected), cr["def"]["title"]])
		_say("[b]ADVISOR:[/b] %s %s" % [cr["def"]["briefing"], cr["def"]["nudge"]])


func _on_submit(text: String) -> void:
	if busy:
		return
	if game_over:
		ui["input"].clear()
		ui["log"].clear()
		_new_game()
		return
	text = text.strip_edges()
	if text.is_empty() or selected == -1 or states[selected]["crisis"] == null:
		return
	ui["input"].clear()
	busy = true
	_refresh()
	_say("\n[b]YOU:[/b] " + text.replace("[", "[lb]"))

	var id := selected
	var cr: Dictionary = states[id]["crisis"]
	var def: Dictionary = cr["def"]
	var t0 := Time.get_ticks_msec()
	var choice: String = await llm.classify(def, text)
	if show_timing and not llm.use_mock:
		_say("[color=gray][i]%.2fs[/i][/color]" % ((Time.get_ticks_msec() - t0) / 1000.0))
	busy = false

	var outcome = null
	if choice == "off_topic":
		patience -= 1
		if patience <= 0:
			_lose("UNFIT TO LEAD. The council has voted, unanimously and in your absence, that you need a long rest.")
			return
		_say("[b]ADVISOR:[/b] %s %s" % [DEFLECT[PATIENCE - patience - 1], def["nudge"]])
		cr["tries"] += 1
	elif choice == "unclear":
		_say("[b]ADVISOR:[/b] I need a decision, Excellency. %s" % def["nudge"])
		cr["tries"] += 1
	else:
		for o in def["outcomes"]:
			if o["id"] == choice:
				outcome = o

	if outcome == null and cr["tries"] >= MAX_TRIES:
		_say("\n[b]ADVISOR:[/b] Events have moved on without us, Excellency.")
		outcome = def["stalled"]
	if outcome == null:
		_refresh()
		return
	_resolve(id, outcome)
	if not game_over:
		_end_month(id)


# ---------- consequences ----------

func _resolve(id: int, outcome: Dictionary) -> void:
	var st: Dictionary = states[id]
	var c: Dictionary = world.countries[id]
	st["crisis"] = null
	map.set_alert(id, -1)
	if briefed == id:
		briefed = -1
	_say("\n" + outcome["result"])

	var notes: Array[String] = []
	var effects: Dictionary = outcome["effects"]
	for key in effects:
		var delta := int(effects[key])
		if delta < 0:
			for t in c["traits"]:
				delta = roundi(delta * float(WorldGen.TRAITS[t]["mult"].get(key, 1.0)))
		if key == "standing":
			standing = clampi(standing + delta, 0, 100)
			notes.append("Standing abroad %+d" % delta)
		else:
			st["meters"][key] = clampi(st["meters"][key] + delta, 0, 100)
			notes.append("%s %+d" % [FACTIONS[key], delta])
	for flag in outcome.get("sets", []):
		st["flags"][flag] = month

	# Some choices land on the neighbours too.
	var spill: Dictionary = outcome.get("spill", {})
	if not spill.is_empty():
		var hit: Array[String] = []
		for n in c["neighbors"]:
			if states[n]["status"] != "active":
				continue
			for key in spill:
				states[n]["meters"][key] = maxi(1, states[n]["meters"][key] + int(spill[key]))
			hit.append(_name(n))
		if not hit.is_empty():
			notes.append("unrest spreads to " + ", ".join(hit))
	_say("[color=gray](%s: %s)[/color]" % [c["name"], ", ".join(notes)])

	for key in FACTIONS:
		if st["meters"][key] <= 0:
			_fall(id, key)
			break
	if not game_over and standing <= 0:
		_lose("ISOLATED. Abroad, the Concord is now spoken of as a problem to be solved. The sanctions are already drafted, and your members are reading them.")
	_refresh()


func _fall(id: int, faction: String) -> void:
	var c: Dictionary = world.countries[id]
	states[id]["status"] = "lost"
	states[id]["crisis"] = null
	map.set_alert(id, -1)
	map.set_state(id, "lost", id == selected)
	lost += 1
	standing = clampi(standing + LOST_STANDING, 0, 100)
	_say("\n[color=#ff8a80][b]%s[/b][/color]" % world.fill(FALLS[faction], c))
	for n in c["neighbors"]:
		if states[n]["status"] == "active":
			states[n]["meters"]["people"] = maxi(1, states[n]["meters"]["people"] - 5)
	if id == home:
		_lose("YOUR SEAT HAS FALLEN. There is no Concord without %s, and no office for you to hold in it." % c["name"])
	elif lost >= MAX_LOST:
		_lose("THE CONCORD DISSOLVES. %d members are gone and the rest have stopped attending. The building in %s is being let as offices." % [lost, world.countries[home]["capital"]])


func _lose(message: String) -> void:
	game_over = true
	busy = false
	_say("\n[b]%s[/b]\n[b]GAME OVER[/b] in month %d." % [message, month])
	_say("[color=gray]Press Enter for a new continent.[/color]")
	_refresh()


func _win() -> void:
	game_over = true
	month = MONTHS
	_say("\n[b]TWO YEARS. The Concord still stands, with %d members.[/b] Nobody would call it loved. It is still here, and so are you." % _active().size())
	_say("[color=gray]Press Enter for a new continent.[/color]")
	_refresh()


# ---------- display ----------

func _refresh() -> void:
	ui["month"].text = "Month %d of %d" % [mini(month, MONTHS), MONTHS]
	ui["standing"].value = standing
	ui["status"].text = "Patience %s   Members %d   Lost %d of %d" % ["●".repeat(patience) + "○".repeat(PATIENCE - patience), _active().size(), lost, MAX_LOST]

	var input: LineEdit = ui["input"]
	var can_type := false
	if selected == -1:
		ui["title"].text = "Select a country"
		ui["traits"].text = ""
		ui["grid"].visible = false
	else:
		var st: Dictionary = states[selected]
		var c: Dictionary = world.countries[selected]
		ui["title"].text = c["name"] + ("  (your seat)" if selected == home else "")
		ui["grid"].visible = st["status"] == "active"
		if st["status"] == "locked":
			ui["traits"].text = "Not a member of the Concord yet."
		elif st["status"] == "lost":
			ui["traits"].text = "Has left the Concord."
		else:
			var text: String = "Capital: %s. %s" % [c["capital"], world.describe_traits(c)]
			if st["crisis"] != null:
				var left: int = st["crisis"]["deadline"]
				text += "\nCrisis: %s (%d month%s left)" % [st["crisis"]["def"]["title"], left, "" if left == 1 else "s"]
				can_type = true
			ui["traits"].text = text
			for key in FACTIONS:
				bars[key].value = st["meters"][key]

	if game_over:
		input.editable = true
		input.placeholder_text = "Press Enter to play again"
	else:
		input.editable = can_type and not busy
		if busy:
			input.placeholder_text = "..."
		elif can_type:
			input.placeholder_text = "Type what you want done, then press Enter"
		else:
			input.placeholder_text = "Click a country marked ! on the map"
	if input.editable:
		input.grab_focus()
