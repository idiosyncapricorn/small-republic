extends Node3D
## Draws a generated world as a low-poly 3D board: one mesh per country,
## a beach rim, water, name labels, capital markers and crisis markers.

const CELL := 1.0
const SEA_FLOOR := -0.45
const BEACH := 0.04
const GREY := Color(0.6, 0.6, 0.56)
const FALLEN := Color(0.32, 0.22, 0.22)
const SAND := Color(0.93, 0.86, 0.66)

var world: RefCounted
var corner_pos := PackedVector3Array()
var meshes: Array[MeshInstance3D] = []
var name_labels: Array[Label3D] = []
var alerts: Array[Label3D] = []
var material: StandardMaterial3D
var clock := 0.0


func build(new_world: RefCounted) -> void:
	for child in get_children():
		child.queue_free()
	meshes.clear()
	name_labels.clear()
	alerts.clear()
	world = new_world

	material = StandardMaterial3D.new()
	material.vertex_color_use_as_albedo = true
	material.vertex_color_is_srgb = true
	material.roughness = 1.0

	_make_corners()
	_add_water_and_beach()
	for c in world.countries:
		var mi := MeshInstance3D.new()
		mi.material_override = material
		add_child(mi)
		meshes.append(mi)

		var top := to_world(c["capital_cell"])
		_add_capital(top)

		var label := Label3D.new()
		label.text = c["name"]
		label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		label.no_depth_test = true
		label.font_size = 72
		label.outline_size = 14
		label.pixel_size = 0.014
		label.position = top + Vector3(0, 2.0, 0)
		add_child(label)
		name_labels.append(label)

		var alert := Label3D.new()
		alert.text = "!"
		alert.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		alert.no_depth_test = true
		alert.font_size = 150
		alert.outline_size = 30
		alert.pixel_size = 0.011
		alert.position = top + Vector3(0, 3.6, 0)
		alert.visible = false
		add_child(alert)
		alerts.append(alert)

		set_state(c["id"], "locked", false)


func _process(delta: float) -> void:
	clock += delta
	for a in alerts:
		if a.visible:
			a.position.y = a.get_meta("base_y", 3.6) + sin(clock * 4.0) * 0.25


# ---------- geometry ----------

func _land_height(h: float) -> float:
	return 0.14 + pow(maxf(h, 0.0), 1.5) * 4.2


func _make_corners() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = world.rng.seed
	var w: int = world.W
	var h: int = world.H
	corner_pos.resize((w + 1) * (h + 1))
	for cy in h + 1:
		for cx in w + 1:
			var land := 0
			var total := 0.0
			for off in [Vector2i(-1, -1), Vector2i(0, -1), Vector2i(-1, 0), Vector2i(0, 0)]:
				var x: int = cx + off.x
				var y: int = cy + off.y
				if x < 0 or y < 0 or x >= w or y >= h:
					continue
				var i: int = world.idx(x, y)
				if world.is_land(i):
					land += 1
					total += _land_height(world.height[i])
			var y_pos := SEA_FLOOR
			if land == 4:
				y_pos = total / 4.0
			elif land > 0:
				y_pos = BEACH
			corner_pos[cy * (w + 1) + cx] = Vector3(
				(cx - w / 2.0 + rng.randf_range(-0.32, 0.32)) * CELL,
				y_pos,
				(cy - h / 2.0 + rng.randf_range(-0.32, 0.32)) * CELL
			)


func _cell_corners(i: int) -> Array[Vector3]:
	var w: int = world.W
	var x := i % w
	var y := i / w
	var row := w + 1
	return [
		corner_pos[y * row + x], corner_pos[y * row + x + 1],
		corner_pos[(y + 1) * row + x + 1], corner_pos[(y + 1) * row + x],
	]


func _add_cell(st: SurfaceTool, i: int, color: Color) -> void:
	var c := _cell_corners(i)
	# Two flat triangles per cell, each a slightly different shade.
	for tri in [[0, 1, 2], [0, 2, 3]]:
		var shade := 0.94 + 0.12 * fmod(absf(sin(i * 12.9898 + tri[1] * 78.233)) * 43758.5453, 1.0)
		st.set_color(Color(color.r * shade, color.g * shade, color.b * shade))
		for k in tri:
			st.add_vertex(c[k])


func _is_border(i: int) -> bool:
	var w: int = world.W
	for n in [i - 1, i + 1, i - w, i + w]:
		if n >= 0 and n < world.owner.size() and world.is_land(n) and world.owner[n] != world.owner[i]:
			return true
	return false


func _add_water_and_beach() -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var any := false
	for i in world.owner.size():
		if world.is_land(i):
			continue
		var corners := _cell_corners(i)
		var shore := SEA_FLOOR + 0.01  # corners are stored as 32-bit floats
		if corners[0].y > shore or corners[1].y > shore or corners[2].y > shore or corners[3].y > shore:
			_add_cell(st, i, SAND)
			any = true
	if any:
		st.generate_normals()
		var beach := MeshInstance3D.new()
		beach.mesh = st.commit()
		beach.material_override = material
		add_child(beach)

	var plane := PlaneMesh.new()
	plane.size = Vector2(world.W + 400, world.H + 400)
	var water := MeshInstance3D.new()
	water.mesh = plane
	var wm := StandardMaterial3D.new()
	wm.albedo_color = Color(0.22, 0.5, 0.78, 0.88)
	wm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	wm.roughness = 0.35
	water.material_override = wm
	add_child(water)

	var floor_mesh := MeshInstance3D.new()
	floor_mesh.mesh = plane
	floor_mesh.position.y = SEA_FLOOR - 0.05
	var fm := StandardMaterial3D.new()
	fm.albedo_color = Color(0.14, 0.36, 0.62)
	floor_mesh.material_override = fm
	add_child(floor_mesh)


func _add_capital(at: Vector3) -> void:
	var tower := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.22
	cyl.bottom_radius = 0.26
	cyl.height = 0.7
	cyl.radial_segments = 6
	tower.mesh = cyl
	tower.position = at + Vector3(0, 0.35, 0)
	var white := StandardMaterial3D.new()
	white.albedo_color = Color(0.97, 0.95, 0.9)
	tower.material_override = white
	add_child(tower)

	var roof := MeshInstance3D.new()
	var cone := CylinderMesh.new()
	cone.top_radius = 0.0
	cone.bottom_radius = 0.36
	cone.height = 0.45
	cone.radial_segments = 6
	roof.mesh = cone
	roof.position = at + Vector3(0, 0.92, 0)
	var red := StandardMaterial3D.new()
	red.albedo_color = Color(0.78, 0.25, 0.22)
	roof.material_override = red
	add_child(roof)


## World position of the centre of a cell, on the ground.
func to_world(cell: int) -> Vector3:
	var c := _cell_corners(cell)
	return (c[0] + c[1] + c[2] + c[3]) / 4.0


# ---------- state ----------

## state is "locked" (not a member yet), "active" or "lost".
func set_state(id: int, state: String, selected: bool) -> void:
	var c: Dictionary = world.countries[id]
	var base: Color = c["color"]
	if state == "locked":
		base = base.lerp(GREY, 0.88)
	elif state == "lost":
		base = base.lerp(FALLEN, 0.85)
	if selected:
		base = base.lightened(0.18)

	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for cell in c["cells"]:
		var h: float = world.height[cell]
		var col := base.lightened(clampf(h * 0.18, 0.0, 0.15))
		col = col.lerp(Color.WHITE, clampf((h - 0.6) * 3.0, 0.0, 0.8))  # snow on the peaks
		if _is_border(cell):
			col = col.darkened(0.22)
		_add_cell(st, cell, col)
	st.generate_normals()
	meshes[id].mesh = st.commit()
	meshes[id].position.y = 0.3 if selected else 0.0

	name_labels[id].modulate = Color(1, 1, 1, 0.55) if state != "active" else Color.WHITE
	name_labels[id].outline_modulate = Color(0.1, 0.1, 0.12, 0.55 if state != "active" else 1.0)


## months_left < 0 hides the marker.
func set_alert(id: int, months_left: int) -> void:
	var a := alerts[id]
	a.visible = months_left >= 0
	a.set_meta("base_y", to_world(world.countries[id]["capital_cell"]).y + 3.6)
	a.modulate = Color(0.95, 0.2, 0.15) if months_left <= 1 else Color(1.0, 0.62, 0.1)
	a.outline_modulate = Color(0.15, 0.05, 0.05)


## Which country is under the mouse? Returns -1 for sea.
func pick(camera: Camera3D, mouse: Vector2) -> int:
	var from := camera.project_ray_origin(mouse)
	var dir := camera.project_ray_normal(mouse)
	if absf(dir.y) < 0.0001:
		return -1
	var hit := from + dir * ((0.4 - from.y) / dir.y)
	var x := int(floor(hit.x / CELL + world.W / 2.0))
	var y := int(floor(hit.z / CELL + world.H / 2.0))
	if x < 0 or y < 0 or x >= world.W or y >= world.H:
		return -1
	return world.owner[world.idx(x, y)]
