extends Node3D
## Orbit camera for the map.
## Right-drag rotates, middle-drag pans, wheel zooms.
## On a trackpad: two-finger scroll pans, pinch zooms.

var camera: Camera3D
var yaw := 0.0
var pitch := 55.0
var distance := 68.0
var limit := Vector2(45, 30)


func _ready() -> void:
	camera = Camera3D.new()
	camera.fov = 45.0
	camera.far = 600.0
	add_child(camera)
	position.x = 14.0  # leaves room for the side panel on the right
	_apply()


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			distance *= 0.9
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			distance *= 1.1
	elif event is InputEventMouseMotion:
		if event.button_mask & MOUSE_BUTTON_MASK_RIGHT:
			yaw -= event.relative.x * 0.3
			pitch += event.relative.y * 0.3
		elif event.button_mask & MOUSE_BUTTON_MASK_MIDDLE:
			_pan(event.relative)
	elif event is InputEventPanGesture:
		_pan(-event.delta * 12.0)
	elif event is InputEventMagnifyGesture:
		distance /= event.factor
	else:
		return
	_apply()


func _pan(pixels: Vector2) -> void:
	var step := distance * 0.0016
	var move := Vector3(-pixels.x * step, 0, -pixels.y * step).rotated(Vector3.UP, deg_to_rad(yaw))
	position.x = clampf(position.x + move.x, -limit.x, limit.x)
	position.z = clampf(position.z + move.z, -limit.y, limit.y)


func _apply() -> void:
	pitch = clampf(pitch, 25.0, 85.0)
	distance = clampf(distance, 14.0, 95.0)
	var offset := Vector3(0, 0, distance)
	offset = offset.rotated(Vector3.RIGHT, deg_to_rad(-pitch)).rotated(Vector3.UP, deg_to_rad(yaw))
	camera.position = offset
	camera.look_at(global_position, Vector3.UP)
